# kdp_api.DatasetsApi

All URIs are relative to *https://api.koverse.dev*

Method | HTTP request | Description
------------- | ------------- | -------------
[**datasets_get**](DatasetsApi.md#datasets_get) | **GET** /datasets | 
[**datasets_id_delete**](DatasetsApi.md#datasets_id_delete) | **DELETE** /datasets/{id} | 
[**datasets_id_get**](DatasetsApi.md#datasets_id_get) | **GET** /datasets/{id} | 
[**datasets_id_patch**](DatasetsApi.md#datasets_id_patch) | **PATCH** /datasets/{id} | 
[**datasets_id_put**](DatasetsApi.md#datasets_id_put) | **PUT** /datasets/{id} | 
[**datasets_post**](DatasetsApi.md#datasets_post) | **POST** /datasets | 


# **datasets_get**
> DatasetPaginator datasets_get()



Retrieves a list of all resources from the service.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import datasets_api
 
from kdp_api.model.dataset_paginator import DatasetPaginator
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = datasets_api.DatasetsApi(api_client)
    limit = 1 # int | Number of results to return (optional)
    skip = 1 # int | Number of results to skip (optional)
    sort = {} # {str: (bool, date, datetime, dict, float, int, list, str, none_type)} | Property to sort results (optional)
    filter = {} # {str: (bool, date, datetime, dict, float, int, list, str, none_type)} | Query parameters to filter (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.datasets_get(limit=limit, skip=skip, sort=sort, filter=filter)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling DatasetsApi->datasets_get: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to return | [optional]
 **skip** | **int**| Number of results to skip | [optional]
 **sort** | **{str: (bool, date, datetime, dict, float, int, list, str, none_type)}**| Property to sort results | [optional]
 **filter** | **{str: (bool, date, datetime, dict, float, int, list, str, none_type)}**| Query parameters to filter | [optional]

### Return type

[**DatasetPaginator**](DatasetPaginator.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **datasets_id_delete**
> Dataset datasets_id_delete(id)



Removes the resource with id.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import datasets_api
from kdp_api.model.dataset import Dataset
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = datasets_api.DatasetsApi(api_client)
    id = "id_example" # str | ID of dataset to remove

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.datasets_id_delete(id)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling DatasetsApi->datasets_id_delete: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of dataset to remove |

### Return type

[**Dataset**](Dataset.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **datasets_id_get**
> Dataset datasets_id_get(id)



Retrieves a single resource with the given id from the service.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import datasets_api
from kdp_api.model.dataset import Dataset
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = datasets_api.DatasetsApi(api_client)
    id = "id_example" # str | ID of dataset to return

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.datasets_id_get(id)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling DatasetsApi->datasets_id_get: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of dataset to return |

### Return type

[**Dataset**](Dataset.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **datasets_id_patch**
> Dataset datasets_id_patch(id, patch_dataset)



Updates the resource identified by id using data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import datasets_api
from kdp_api.model.patch_dataset import PatchDataset
from kdp_api.model.dataset import Dataset
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = datasets_api.DatasetsApi(api_client)
    id = "id_example" # str | ID of dataset to update
    patch_dataset = PatchDataset(
        id="id_example",
        name="name_example",
        record_count=3.14,
        description="description_example",
        auto_create_indexes=True,
        schema={},
        search_any_field=True,
    ) # PatchDataset | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.datasets_id_patch(id, patch_dataset)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling DatasetsApi->datasets_id_patch: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of dataset to update |
 **patch_dataset** | [**PatchDataset**](PatchDataset.md)|  |

### Return type

[**Dataset**](Dataset.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **datasets_id_put**
> Dataset datasets_id_put(id, update_dataset)



Updates the resource identified by id using data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import datasets_api
from kdp_api.model.update_dataset import UpdateDataset
from kdp_api.model.dataset import Dataset
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = datasets_api.DatasetsApi(api_client)
    id = "id_example" # str | ID of dataset to update
    update_dataset = UpdateDataset(
        id="id_example",
        name="name_example",
        record_count=3.14,
        description="description_example",
        auto_create_indexes=True,
        schema={},
        search_any_field=True,
    ) # UpdateDataset | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.datasets_id_put(id, update_dataset)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling DatasetsApi->datasets_id_put: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of dataset to update |
 **update_dataset** | [**UpdateDataset**](UpdateDataset.md)|  |

### Return type

[**Dataset**](Dataset.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **datasets_post**
> Dataset datasets_post(create_dataset)



Creates a new resource with data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import datasets_api
from kdp_api.model.create_dataset import CreateDataset
from kdp_api.model.dataset import Dataset
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = datasets_api.DatasetsApi(api_client)
    create_dataset = CreateDataset(
        name="name_example",
        record_count=3.14,
        description="description_example",
        auto_create_indexes=True,
        schema={},
        search_any_field=True,
        workspace_id="workspace_id_example",
    ) # CreateDataset | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.datasets_post(create_dataset)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling DatasetsApi->datasets_post: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **create_dataset** | [**CreateDataset**](CreateDataset.md)|  |

### Return type

[**Dataset**](Dataset.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | created |  -  |
**401** | not authenticated |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

