# kdp_api.QueryApi

All URIs are relative to *https://api.koverse.dev*

Method | HTTP request | Description
------------- | ------------- | -------------
[**lucene_query**](QueryApi.md#lucene_query) | **POST** /query/lucene | Query a dataset but run it through the LuceneParser first
[**query**](QueryApi.md#query) | **POST** /query | Query a dataset


# **lucene_query**
> RecordBatch lucene_query(query)

Query a dataset but run it through the LuceneParser first

Runs the expression through the LuceneParser then executes a query against the given dataset and returns resulting records

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import query_api
from kdp_api.model.record_batch import RecordBatch
from kdp_api.model.query import Query
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = query_api.QueryApi(api_client)
    query = Query(
        dataset_id="dataset_id_example",
        expression="expression_example",
        limit=1,
        offset=1,
        credentials_subset=[
            "credentials_subset_example",
        ],
    ) # Query | 

    # example passing only required values which don't have defaults set
    try:
        # Query a dataset but run it through the LuceneParser first
        api_response = api_instance.lucene_query(query)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling QueryApi->lucene_query: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | [**Query**](Query.md)|  |

### Return type

[**RecordBatch**](RecordBatch.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query**
> RecordBatch query(query)

Query a dataset

Executes a query against the given dataset and returns resulting records

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import query_api
from kdp_api.model.record_batch import RecordBatch
from kdp_api.model.query import Query
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = query_api.QueryApi(api_client)
    query = Query(
        dataset_id="dataset_id_example",
        expression="expression_example",
        limit=1,
        offset=1,
        credentials_subset=[
            "credentials_subset_example",
        ],
    ) # Query | 

    # example passing only required values which don't have defaults set
    try:
        # Query a dataset
        api_response = api_instance.query(query)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling QueryApi->query: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | [**Query**](Query.md)|  |

### Return type

[**RecordBatch**](RecordBatch.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

