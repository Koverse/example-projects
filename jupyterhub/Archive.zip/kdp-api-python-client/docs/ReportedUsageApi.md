# kdp_api.ReportedUsageApi

All URIs are relative to *https://api.koverse.dev*

Method | HTTP request | Description
------------- | ------------- | -------------
[**reported_usage_get**](ReportedUsageApi.md#reported_usage_get) | **GET** /reported-usage | 
[**reported_usage_id_delete**](ReportedUsageApi.md#reported_usage_id_delete) | **DELETE** /reported-usage/{id} | 
[**reported_usage_id_get**](ReportedUsageApi.md#reported_usage_id_get) | **GET** /reported-usage/{id} | 
[**reported_usage_id_patch**](ReportedUsageApi.md#reported_usage_id_patch) | **PATCH** /reported-usage/{id} | 
[**reported_usage_id_put**](ReportedUsageApi.md#reported_usage_id_put) | **PUT** /reported-usage/{id} | 
[**reported_usage_post**](ReportedUsageApi.md#reported_usage_post) | **POST** /reported-usage | 


# **reported_usage_get**
> ReportedUsagePaginator reported_usage_get()



Retrieves a list of all resources from the service.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import reported_usage_api
 
from kdp_api.model.reported_usage_paginator import ReportedUsagePaginator
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = reported_usage_api.ReportedUsageApi(api_client)
    id = "id_example" # str | id (optional)
    start = "start_example" # str | start (optional)
    end = "end_example" # str | end (optional)
    subscription_item_id = "subscriptionItemId_example" # str | subscriptionItemId (optional)
    daily_usage_id = "dailyUsageId_example" # str | dailyUsageId (optional)
    stripe_usage_id = "stripeUsageId_example" # str | stripeUsageId (optional)
    workspace_id = "workspaceId_example" # str | workspaceId (optional)
    limit = 1 # int | Number of results to return (optional)
    skip = 1 # int | Number of results to skip (optional)
    sort = {} # {str: (bool, date, datetime, dict, float, int, list, str, none_type)} | Property to sort results (optional)
    filter = {} # {str: (bool, date, datetime, dict, float, int, list, str, none_type)} | Query parameters to filter (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.reported_usage_get(id=id, start=start, end=end, subscription_item_id=subscription_item_id, daily_usage_id=daily_usage_id, stripe_usage_id=stripe_usage_id, workspace_id=workspace_id, limit=limit, skip=skip, sort=sort, filter=filter)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling ReportedUsageApi->reported_usage_get: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| id | [optional]
 **start** | **str**| start | [optional]
 **end** | **str**| end | [optional]
 **subscription_item_id** | **str**| subscriptionItemId | [optional]
 **daily_usage_id** | **str**| dailyUsageId | [optional]
 **stripe_usage_id** | **str**| stripeUsageId | [optional]
 **workspace_id** | **str**| workspaceId | [optional]
 **limit** | **int**| Number of results to return | [optional]
 **skip** | **int**| Number of results to skip | [optional]
 **sort** | **{str: (bool, date, datetime, dict, float, int, list, str, none_type)}**| Property to sort results | [optional]
 **filter** | **{str: (bool, date, datetime, dict, float, int, list, str, none_type)}**| Query parameters to filter | [optional]

### Return type

[**ReportedUsagePaginator**](ReportedUsagePaginator.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **reported_usage_id_delete**
> ReportedUsage reported_usage_id_delete(id)



Removes the resource with id.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import reported_usage_api
from kdp_api.model.reported_usage import ReportedUsage
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = reported_usage_api.ReportedUsageApi(api_client)
    id = "id_example" # str | ID of reported-usage to remove

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.reported_usage_id_delete(id)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling ReportedUsageApi->reported_usage_id_delete: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of reported-usage to remove |

### Return type

[**ReportedUsage**](ReportedUsage.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **reported_usage_id_get**
> ReportedUsage reported_usage_id_get(id)



Retrieves a single resource with the given id from the service.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import reported_usage_api
from kdp_api.model.reported_usage import ReportedUsage
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = reported_usage_api.ReportedUsageApi(api_client)
    id = "id_example" # str | ID of reported-usage to return

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.reported_usage_id_get(id)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling ReportedUsageApi->reported_usage_id_get: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of reported-usage to return |

### Return type

[**ReportedUsage**](ReportedUsage.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **reported_usage_id_patch**
> ReportedUsage reported_usage_id_patch(id, reported_usage)



Updates the resource identified by id using data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import reported_usage_api
from kdp_api.model.reported_usage import ReportedUsage
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = reported_usage_api.ReportedUsageApi(api_client)
    id = "id_example" # str | ID of reported-usage to update
    reported_usage = ReportedUsage(
        id="id_example",
        product="compute",
        unit="hours",
        quantity=3.14,
        subscription_item_id="subscription_item_id_example",
        stripe_usage_id="stripe_usage_id_example",
        workspace_id="workspace_id_example",
        reported_date="reported_date_example",
        message="message_example",
    ) # ReportedUsage | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.reported_usage_id_patch(id, reported_usage)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling ReportedUsageApi->reported_usage_id_patch: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of reported-usage to update |
 **reported_usage** | [**ReportedUsage**](ReportedUsage.md)|  |

### Return type

[**ReportedUsage**](ReportedUsage.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **reported_usage_id_put**
> ReportedUsage reported_usage_id_put(id, reported_usage)



Updates the resource identified by id using data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import reported_usage_api
from kdp_api.model.reported_usage import ReportedUsage
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = reported_usage_api.ReportedUsageApi(api_client)
    id = "id_example" # str | ID of reported-usage to update
    reported_usage = ReportedUsage(
        id="id_example",
        product="compute",
        unit="hours",
        quantity=3.14,
        subscription_item_id="subscription_item_id_example",
        stripe_usage_id="stripe_usage_id_example",
        workspace_id="workspace_id_example",
        reported_date="reported_date_example",
        message="message_example",
    ) # ReportedUsage | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.reported_usage_id_put(id, reported_usage)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling ReportedUsageApi->reported_usage_id_put: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of reported-usage to update |
 **reported_usage** | [**ReportedUsage**](ReportedUsage.md)|  |

### Return type

[**ReportedUsage**](ReportedUsage.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **reported_usage_post**
> ReportedUsage reported_usage_post(reported_usage)



Creates a new resource with data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import reported_usage_api
from kdp_api.model.reported_usage import ReportedUsage
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = reported_usage_api.ReportedUsageApi(api_client)
    reported_usage = ReportedUsage(
        id="id_example",
        product="compute",
        unit="hours",
        quantity=3.14,
        subscription_item_id="subscription_item_id_example",
        stripe_usage_id="stripe_usage_id_example",
        workspace_id="workspace_id_example",
        reported_date="reported_date_example",
        message="message_example",
    ) # ReportedUsage | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.reported_usage_post(reported_usage)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling ReportedUsageApi->reported_usage_post: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **reported_usage** | [**ReportedUsage**](ReportedUsage.md)|  |

### Return type

[**ReportedUsage**](ReportedUsage.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | created |  -  |
**401** | not authenticated |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

