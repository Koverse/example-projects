# kdp_api.WorkspaceInvitationsApi

All URIs are relative to *https://api.koverse.dev*

Method | HTTP request | Description
------------- | ------------- | -------------
[**workspace_invitations_get**](WorkspaceInvitationsApi.md#workspace_invitations_get) | **GET** /workspace-invitations | 
[**workspace_invitations_id_delete**](WorkspaceInvitationsApi.md#workspace_invitations_id_delete) | **DELETE** /workspace-invitations/{id} | 
[**workspace_invitations_id_get**](WorkspaceInvitationsApi.md#workspace_invitations_id_get) | **GET** /workspace-invitations/{id} | 
[**workspace_invitations_id_patch**](WorkspaceInvitationsApi.md#workspace_invitations_id_patch) | **PATCH** /workspace-invitations/{id} | 
[**workspace_invitations_id_put**](WorkspaceInvitationsApi.md#workspace_invitations_id_put) | **PUT** /workspace-invitations/{id} | 
[**workspace_invitations_post**](WorkspaceInvitationsApi.md#workspace_invitations_post) | **POST** /workspace-invitations | 


# **workspace_invitations_get**
> WorkspaceInvitationPaginator workspace_invitations_get()



Retrieves a list of all resources from the service.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import workspace_invitations_api
 
from kdp_api.model.workspace_invitation_paginator import WorkspaceInvitationPaginator
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = workspace_invitations_api.WorkspaceInvitationsApi(api_client)
    limit = 1 # int | Number of results to return (optional)
    skip = 1 # int | Number of results to skip (optional)
    sort = {} # {str: (bool, date, datetime, dict, float, int, list, str, none_type)} | Property to sort results (optional)
    filter = {} # {str: (bool, date, datetime, dict, float, int, list, str, none_type)} | Query parameters to filter (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.workspace_invitations_get(limit=limit, skip=skip, sort=sort, filter=filter)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling WorkspaceInvitationsApi->workspace_invitations_get: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to return | [optional]
 **skip** | **int**| Number of results to skip | [optional]
 **sort** | **{str: (bool, date, datetime, dict, float, int, list, str, none_type)}**| Property to sort results | [optional]
 **filter** | **{str: (bool, date, datetime, dict, float, int, list, str, none_type)}**| Query parameters to filter | [optional]

### Return type

[**WorkspaceInvitationPaginator**](WorkspaceInvitationPaginator.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **workspace_invitations_id_delete**
> WorkspaceInvitation workspace_invitations_id_delete(id)



Removes the resource with id.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import workspace_invitations_api
from kdp_api.model.workspace_invitation import WorkspaceInvitation
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = workspace_invitations_api.WorkspaceInvitationsApi(api_client)
    id = "id_example" # str | ID of workspace-invitation to remove

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.workspace_invitations_id_delete(id)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling WorkspaceInvitationsApi->workspace_invitations_id_delete: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of workspace-invitation to remove |

### Return type

[**WorkspaceInvitation**](WorkspaceInvitation.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **workspace_invitations_id_get**
> WorkspaceInvitation workspace_invitations_id_get(id)



Retrieves a single resource with the given id from the service.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import workspace_invitations_api
from kdp_api.model.workspace_invitation import WorkspaceInvitation
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = workspace_invitations_api.WorkspaceInvitationsApi(api_client)
    id = "id_example" # str | ID of workspace-invitation to return

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.workspace_invitations_id_get(id)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling WorkspaceInvitationsApi->workspace_invitations_id_get: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of workspace-invitation to return |

### Return type

[**WorkspaceInvitation**](WorkspaceInvitation.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **workspace_invitations_id_patch**
> WorkspaceInvitation workspace_invitations_id_patch(id, workspace_invitation)



Updates the resource identified by id using data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import workspace_invitations_api
from kdp_api.model.workspace_invitation import WorkspaceInvitation
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = workspace_invitations_api.WorkspaceInvitationsApi(api_client)
    id = "id_example" # str | ID of workspace-invitation to update
    workspace_invitation = WorkspaceInvitation(
        user_id="user_id_example",
        workspace_id="workspace_id_example",
        role="member",
        email="email_example",
    ) # WorkspaceInvitation | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.workspace_invitations_id_patch(id, workspace_invitation)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling WorkspaceInvitationsApi->workspace_invitations_id_patch: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of workspace-invitation to update |
 **workspace_invitation** | [**WorkspaceInvitation**](WorkspaceInvitation.md)|  |

### Return type

[**WorkspaceInvitation**](WorkspaceInvitation.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **workspace_invitations_id_put**
> WorkspaceInvitation workspace_invitations_id_put(id, workspace_invitation)



Updates the resource identified by id using data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import workspace_invitations_api
from kdp_api.model.workspace_invitation import WorkspaceInvitation
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = workspace_invitations_api.WorkspaceInvitationsApi(api_client)
    id = "id_example" # str | ID of workspace-invitation to update
    workspace_invitation = WorkspaceInvitation(
        user_id="user_id_example",
        workspace_id="workspace_id_example",
        role="member",
        email="email_example",
    ) # WorkspaceInvitation | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.workspace_invitations_id_put(id, workspace_invitation)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling WorkspaceInvitationsApi->workspace_invitations_id_put: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of workspace-invitation to update |
 **workspace_invitation** | [**WorkspaceInvitation**](WorkspaceInvitation.md)|  |

### Return type

[**WorkspaceInvitation**](WorkspaceInvitation.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **workspace_invitations_post**
> WorkspaceInvitation workspace_invitations_post(workspace_invitation)



Creates a new resource with data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import workspace_invitations_api
from kdp_api.model.workspace_invitation import WorkspaceInvitation
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = workspace_invitations_api.WorkspaceInvitationsApi(api_client)
    workspace_invitation = WorkspaceInvitation(
        user_id="user_id_example",
        workspace_id="workspace_id_example",
        role="member",
        email="email_example",
    ) # WorkspaceInvitation | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.workspace_invitations_post(workspace_invitation)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling WorkspaceInvitationsApi->workspace_invitations_post: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workspace_invitation** | [**WorkspaceInvitation**](WorkspaceInvitation.md)|  |

### Return type

[**WorkspaceInvitation**](WorkspaceInvitation.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | created |  -  |
**401** | not authenticated |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

