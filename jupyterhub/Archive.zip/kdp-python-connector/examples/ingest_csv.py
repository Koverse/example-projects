from pprint import pprint

import pandas as pd

from kdp_connector import KdpConn

# This example shows you how to use the KDP Python Connector to write data into KDP platform
# from Pandas dataframe sourced from a csv file.


########## variables ##########
# authentication code
email = '${email}'
password = '${password}'

# workspace id
workspace_id = '${WORKSPACE_ID}'

# dataset id
dataset_id = '${DATASET_ID}'

# host url to KDP platform
host = 'https://${KDP_API_HOST}'

# number of records in a batch
batch_size = 10

# csv file location
input_file='${PATH_TO_CSV_FILE}'

# OPTIONAL: When not provided will not verify ssl of request. Which will result in warnings in the log.
# See configuration/configurationUtil.py for more detail about using certificates for ssl.
path_to_ca_file = ''

##################################################

# Read input into dataframe
df = pd.read_csv(input_file)

# Construct kdpConnector
kdp_conn = KdpConn(path_to_ca_file, host)

jwt = kdp_conn.create_authentication_token(email=email,
                                           password=password,
                                           workspace_id=workspace_id)
# ingest data
partitions_set = kdp_conn.ingest(df, dataset_id, jwt, batch_size)

pprint('partitions: %s' % partitions_set)
