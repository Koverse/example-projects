import kdp_api as kdp_api_client
from kdp_api.api.datasets_api import DatasetsApi
from kdp_api.api.workspaces_api import WorkspacesApi


class KdpApi(object):

    @staticmethod
    def create_dataset(config, name: str, workspace_id: str, description: str = '', auto_create_indexes: bool = True,
                       schema: str = '{}', search_any_field: bool = True, record_count: int = 0):

        with kdp_api_client.ApiClient(config) as api_client:
            request_body = {
                    'name': name,
                    'record_count': record_count,
                    'description': description,
                    'auto_create_indexes': auto_create_indexes,
                    'schema': schema,
                    'search_any_field': search_any_field,
                    'workspace_id': workspace_id
                }

            datasets_api = DatasetsApi(api_client)
            return datasets_api.datasets_post(create_dataset=request_body)

    @staticmethod
    def create_workspace(config, name: str, workspace_id: str):

        with kdp_api_client.ApiClient(config) as api_client:

            request_body = {
                'name': name,
                'id': workspace_id if workspace_id != '' else name
            }
            workspaces_api = WorkspacesApi(api_client)
            return workspaces_api.workspaces_post(workspace1=request_body)

    @staticmethod
    def get_workspace(config, workspace_id: str):

        with kdp_api_client.ApiClient(config) as api_client:

            workspaces_api = WorkspacesApi(api_client)
            return workspaces_api.workspaces_id_get(workspace_id)

    @staticmethod
    def get_dataset(config, dataset_id: str):

        with kdp_api_client.ApiClient(config) as api_client:

            datasets_api = DatasetsApi(api_client)
            return datasets_api.datasets_id_get(dataset_id)
