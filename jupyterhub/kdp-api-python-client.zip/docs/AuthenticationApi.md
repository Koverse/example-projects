# kdp_api.AuthenticationApi

All URIs are relative to *https://api.koverse.dev*

Method | HTTP request | Description
------------- | ------------- | -------------
[**authentication_id_delete**](AuthenticationApi.md#authentication_id_delete) | **DELETE** /authentication/{id} | 
[**authentication_post**](AuthenticationApi.md#authentication_post) | **POST** /authentication | 


# **authentication_id_delete**
> Authentication authentication_id_delete(id)



Removes the resource with id.

### Example


```python
import time
import kdp_api
from kdp_api.api import authentication_api
from kdp_api.model.authentication import Authentication
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)


# Enter a context with an instance of the API client
with kdp_api.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = authentication_api.AuthenticationApi(api_client)
    id = "id_example" # str | ID of authentication to remove

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.authentication_id_delete(id)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling AuthenticationApi->authentication_id_delete: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of authentication to remove |

### Return type

[**Authentication**](Authentication.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **authentication_post**
> AuthenticationDetails authentication_post(authentication)



Creates a new resource with data.

### Example


```python
import time
import kdp_api
from kdp_api.api import authentication_api
from kdp_api.model.authentication import Authentication
from kdp_api.model.authentication_details import AuthenticationDetails
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)


# Enter a context with an instance of the API client
with kdp_api.ApiClient() as api_client:
    # Create an instance of the API class
    api_instance = authentication_api.AuthenticationApi(api_client)
    authentication = Authentication(None) # Authentication | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.authentication_post(authentication)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling AuthenticationApi->authentication_post: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authentication** | [**Authentication**](Authentication.md)|  |

### Return type

[**AuthenticationDetails**](AuthenticationDetails.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Authentication was successful |  -  |
**401** | not authenticated |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

