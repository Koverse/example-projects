# AuthenticationDetailsUser


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**avatar** | **str** |  | [optional] 
**change_email_token_expiration** | **str** |  | [optional] 
**created_at** | **str** |  | [optional] 
**deleted_at** | **str** |  | [optional] 
**display_name** | **str** |  | [optional] 
**email** | **str** |  | [optional] 
**first_name** | **str** |  | [optional] 
**github_id** | **str** |  | [optional] 
**google_id** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**last_name** | **str** |  | [optional] 
**linked_accounts** | **[str]** |  | [optional] 
**microsoft_id** | **str** |  | [optional] 
**okta_id** | **str** |  | [optional] 
**stripe_customer_id** | **str** |  | [optional] 
**updated_at** | **str** |  | [optional] 
**verified** | **bool** |  | [optional] 
**workspace_count** | **float** |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


