# kdp_api.DailyUsageApi

All URIs are relative to *https://api.koverse.dev*

Method | HTTP request | Description
------------- | ------------- | -------------
[**daily_usage_get**](DailyUsageApi.md#daily_usage_get) | **GET** /daily-usage | 
[**daily_usage_id_delete**](DailyUsageApi.md#daily_usage_id_delete) | **DELETE** /daily-usage/{id} | 
[**daily_usage_id_get**](DailyUsageApi.md#daily_usage_id_get) | **GET** /daily-usage/{id} | 
[**daily_usage_id_patch**](DailyUsageApi.md#daily_usage_id_patch) | **PATCH** /daily-usage/{id} | 
[**daily_usage_id_put**](DailyUsageApi.md#daily_usage_id_put) | **PUT** /daily-usage/{id} | 
[**daily_usage_post**](DailyUsageApi.md#daily_usage_post) | **POST** /daily-usage | 


# **daily_usage_get**
> DailyUsagePaginator daily_usage_get()



Retrieves a list of all resources from the service.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import daily_usage_api
 
from kdp_api.model.daily_usage_paginator import DailyUsagePaginator
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = daily_usage_api.DailyUsageApi(api_client)
    id = "id_example" # str | id (optional)
    product = "product_example" # str | product (optional)
    unit = "unit_example" # str | unit (optional)
    start = "start_example" # str | start (optional)
    end = "end_example" # str | end (optional)
    workspace_id = "workspaceId_example" # str | workspaceId (optional)
    limit = 1 # int | Number of results to return (optional)
    skip = 1 # int | Number of results to skip (optional)
    sort = {} # {str: (bool, date, datetime, dict, float, int, list, str, none_type)} | Property to sort results (optional)
    filter = {} # {str: (bool, date, datetime, dict, float, int, list, str, none_type)} | Query parameters to filter (optional)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.daily_usage_get(id=id, product=product, unit=unit, start=start, end=end, workspace_id=workspace_id, limit=limit, skip=skip, sort=sort, filter=filter)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling DailyUsageApi->daily_usage_get: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| id | [optional]
 **product** | **str**| product | [optional]
 **unit** | **str**| unit | [optional]
 **start** | **str**| start | [optional]
 **end** | **str**| end | [optional]
 **workspace_id** | **str**| workspaceId | [optional]
 **limit** | **int**| Number of results to return | [optional]
 **skip** | **int**| Number of results to skip | [optional]
 **sort** | **{str: (bool, date, datetime, dict, float, int, list, str, none_type)}**| Property to sort results | [optional]
 **filter** | **{str: (bool, date, datetime, dict, float, int, list, str, none_type)}**| Query parameters to filter | [optional]

### Return type

[**DailyUsagePaginator**](DailyUsagePaginator.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **daily_usage_id_delete**
> DailyUsage daily_usage_id_delete(id)



Removes the resource with id.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import daily_usage_api
from kdp_api.model.daily_usage import DailyUsage
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = daily_usage_api.DailyUsageApi(api_client)
    id = "id_example" # str | ID of daily-usage to remove

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.daily_usage_id_delete(id)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling DailyUsageApi->daily_usage_id_delete: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of daily-usage to remove |

### Return type

[**DailyUsage**](DailyUsage.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **daily_usage_id_get**
> DailyUsage daily_usage_id_get(id)



Retrieves a single resource with the given id from the service.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import daily_usage_api
from kdp_api.model.daily_usage import DailyUsage
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = daily_usage_api.DailyUsageApi(api_client)
    id = "id_example" # str | ID of daily-usage to return

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.daily_usage_id_get(id)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling DailyUsageApi->daily_usage_id_get: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of daily-usage to return |

### Return type

[**DailyUsage**](DailyUsage.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **daily_usage_id_patch**
> DailyUsage daily_usage_id_patch(id, daily_usage)



Updates the resource identified by id using data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import daily_usage_api
from kdp_api.model.daily_usage import DailyUsage
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = daily_usage_api.DailyUsageApi(api_client)
    id = "id_example" # str | ID of daily-usage to update
    daily_usage = DailyUsage(
        id="id_example",
        product="compute",
        unit="seconds",
        quantity=3.14,
        usage_date="usage_date_example",
        workspace_id="workspace_id_example",
    ) # DailyUsage | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.daily_usage_id_patch(id, daily_usage)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling DailyUsageApi->daily_usage_id_patch: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of daily-usage to update |
 **daily_usage** | [**DailyUsage**](DailyUsage.md)|  |

### Return type

[**DailyUsage**](DailyUsage.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **daily_usage_id_put**
> DailyUsage daily_usage_id_put(id, daily_usage)



Updates the resource identified by id using data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import daily_usage_api
from kdp_api.model.daily_usage import DailyUsage
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = daily_usage_api.DailyUsageApi(api_client)
    id = "id_example" # str | ID of daily-usage to update
    daily_usage = DailyUsage(
        id="id_example",
        product="compute",
        unit="seconds",
        quantity=3.14,
        usage_date="usage_date_example",
        workspace_id="workspace_id_example",
    ) # DailyUsage | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.daily_usage_id_put(id, daily_usage)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling DailyUsageApi->daily_usage_id_put: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of daily-usage to update |
 **daily_usage** | [**DailyUsage**](DailyUsage.md)|  |

### Return type

[**DailyUsage**](DailyUsage.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **daily_usage_post**
> DailyUsage daily_usage_post(daily_usage)



Creates a new resource with data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import daily_usage_api
from kdp_api.model.daily_usage import DailyUsage
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = daily_usage_api.DailyUsageApi(api_client)
    daily_usage = DailyUsage(
        id="id_example",
        product="compute",
        unit="seconds",
        quantity=3.14,
        usage_date="usage_date_example",
        workspace_id="workspace_id_example",
    ) # DailyUsage | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.daily_usage_post(daily_usage)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling DailyUsageApi->daily_usage_post: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **daily_usage** | [**DailyUsage**](DailyUsage.md)|  |

### Return type

[**DailyUsage**](DailyUsage.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | created |  -  |
**401** | not authenticated |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

