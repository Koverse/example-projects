# kdp_api.IndexesApi

All URIs are relative to *https://api.koverse.dev*

Method | HTTP request | Description
------------- | ------------- | -------------
[**indexes_get**](IndexesApi.md#indexes_get) | **GET** /indexes | 
[**indexes_id_delete**](IndexesApi.md#indexes_id_delete) | **DELETE** /indexes/{id} | 
[**indexes_id_get**](IndexesApi.md#indexes_id_get) | **GET** /indexes/{id} | 
[**indexes_id_patch**](IndexesApi.md#indexes_id_patch) | **PATCH** /indexes/{id} | 
[**indexes_id_put**](IndexesApi.md#indexes_id_put) | **PUT** /indexes/{id} | 
[**indexes_post**](IndexesApi.md#indexes_post) | **POST** /indexes | 


# **indexes_get**
> IndexPaginator indexes_get(dataset_id)



Retrieves a list of all resources from the service.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import indexes_api
 
from kdp_api.model.index_paginator import IndexPaginator
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = indexes_api.IndexesApi(api_client)
    dataset_id = "datasetId_example" # str | dataset id
    fields = True # bool | populate fields (optional)
    limit = 1 # int | Number of results to return (optional)
    skip = 1 # int | Number of results to skip (optional)
    sort = {} # {str: (bool, date, datetime, dict, float, int, list, str, none_type)} | Property to sort results (optional)
    filter = {} # {str: (bool, date, datetime, dict, float, int, list, str, none_type)} | Query parameters to filter (optional)

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.indexes_get(dataset_id)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling IndexesApi->indexes_get: %s\n" % e)

    # example passing only required values which don't have defaults set
    # and optional values
    try:
        api_response = api_instance.indexes_get(dataset_id, fields=fields, limit=limit, skip=skip, sort=sort, filter=filter)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling IndexesApi->indexes_get: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dataset_id** | **str**| dataset id |
 **fields** | **bool**| populate fields | [optional]
 **limit** | **int**| Number of results to return | [optional]
 **skip** | **int**| Number of results to skip | [optional]
 **sort** | **{str: (bool, date, datetime, dict, float, int, list, str, none_type)}**| Property to sort results | [optional]
 **filter** | **{str: (bool, date, datetime, dict, float, int, list, str, none_type)}**| Query parameters to filter | [optional]

### Return type

[**IndexPaginator**](IndexPaginator.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **indexes_id_delete**
> Index indexes_id_delete(id)



Removes the resource with id.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import indexes_api
from kdp_api.model.index import Index
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = indexes_api.IndexesApi(api_client)
    id = "id_example" # str | ID of index to remove

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.indexes_id_delete(id)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling IndexesApi->indexes_id_delete: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of index to remove |

### Return type

[**Index**](Index.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **indexes_id_get**
> Index indexes_id_get(id)



Retrieves a single resource with the given id from the service.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import indexes_api
from kdp_api.model.index import Index
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = indexes_api.IndexesApi(api_client)
    id = "id_example" # str | ID of index to return

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.indexes_id_get(id)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling IndexesApi->indexes_id_get: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of index to return |

### Return type

[**Index**](Index.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **indexes_id_patch**
> Index indexes_id_patch(id, index)



Updates the resource identified by id using data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import indexes_api
from kdp_api.model.index import Index
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = indexes_api.IndexesApi(api_client)
    id = "id_example" # str | ID of index to update
    index = Index(
        id="id_example",
        dataset_id="dataset_id_example",
        fields=[
            "fields_example",
        ],
    ) # Index | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.indexes_id_patch(id, index)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling IndexesApi->indexes_id_patch: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of index to update |
 **index** | [**Index**](Index.md)|  |

### Return type

[**Index**](Index.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **indexes_id_put**
> Index indexes_id_put(id, index)



Updates the resource identified by id using data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import indexes_api
from kdp_api.model.index import Index
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = indexes_api.IndexesApi(api_client)
    id = "id_example" # str | ID of index to update
    index = Index(
        id="id_example",
        dataset_id="dataset_id_example",
        fields=[
            "fields_example",
        ],
    ) # Index | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.indexes_id_put(id, index)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling IndexesApi->indexes_id_put: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| ID of index to update |
 **index** | [**Index**](Index.md)|  |

### Return type

[**Index**](Index.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | success |  -  |
**401** | not authenticated |  -  |
**404** | not found |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **indexes_post**
> Index indexes_post(index)



Creates a new resource with data.

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import indexes_api
from kdp_api.model.index import Index
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = indexes_api.IndexesApi(api_client)
    index = Index(
        id="id_example",
        dataset_id="dataset_id_example",
        fields=[
            "fields_example",
        ],
    ) # Index | 

    # example passing only required values which don't have defaults set
    try:
        api_response = api_instance.indexes_post(index)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling IndexesApi->indexes_post: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **index** | [**Index**](Index.md)|  |

### Return type

[**Index**](Index.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | created |  -  |
**401** | not authenticated |  -  |
**500** | general error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

