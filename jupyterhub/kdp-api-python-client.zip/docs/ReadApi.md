# kdp_api.ReadApi

All URIs are relative to *https://api.koverse.dev*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_splits**](ReadApi.md#get_splits) | **GET** /splits/{datasetId} | Get split points
[**read**](ReadApi.md#read) | **POST** /read | Read records
[**read_in_sequence**](ReadApi.md#read_in_sequence) | **POST** /readInSequence | Read all records for dataset


# **get_splits**
> SplitPoints get_splits(dataset_id)

Get split points

Get a list of split points

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import read_api
from kdp_api.model.split_points import SplitPoints
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = read_api.ReadApi(api_client)
    dataset_id = "datasetId_example" # str | 

    # example passing only required values which don't have defaults set
    try:
        # Get split points
        api_response = api_instance.get_splits(dataset_id)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling ReadApi->get_splits: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dataset_id** | **str**|  |

### Return type

[**SplitPoints**](SplitPoints.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **read**
> RecordBatch read(read_range_request)

Read records

Read a batch of records from partitions

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import read_api
from kdp_api.model.read_range_request import ReadRangeRequest
from kdp_api.model.record_batch import RecordBatch
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = read_api.ReadApi(api_client)
    read_range_request = ReadRangeRequest(
        dataset_id="dataset_id_example",
        starting_record_id="starting_record_id_example",
        ending_record_id="ending_record_id_example",
        exclude_starting_record_id=True,
        batch_size=1,
        credentials_subset=[
            "credentials_subset_example",
        ],
    ) # ReadRangeRequest | 

    # example passing only required values which don't have defaults set
    try:
        # Read records
        api_response = api_instance.read(read_range_request)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling ReadApi->read: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **read_range_request** | [**ReadRangeRequest**](ReadRangeRequest.md)|  |

### Return type

[**RecordBatch**](RecordBatch.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **read_in_sequence**
> RecordBatch read_in_sequence(sequence_read_request)

Read all records for dataset

<h2>Read records from dataset in sequence.</h2><h3>Request properties</h3><b>datasetId:</b> <i>string</i>, id of dataset to read<br><b>batchsize:</b> <i>integer</i>, the number of records returned in a single batch. <br><b>startingRecordId:</b> <i>string</i>, the last record from the previous batch (batch will start from the record after startingRecordId). <br><b>credentialsSubset:</b> <i>list of strings</i>, subset of users credentials (for viewing results with less credentials) </p><h3>Response properties</h3><p><b>records:</b> <i>list of records</i>, records returned in current batch <br><b>lastRecordId:</b> <i>string</i>, last record read, which can be used for startingRecordId of the next call. <br><b>more:</b> <i>boolean</i>, indicates if there are more records to be read. <br><b>total:</b> <i>integer</i>, total number of records that exist in the dataset. </p>

### Example

* Bearer (JWT) Authentication (Bearer):

```python
import time
import kdp_api
from kdp_api.api import read_api
from kdp_api.model.record_batch import RecordBatch
from kdp_api.model.sequence_read_request import SequenceReadRequest
from pprint import pprint
# Defining the host is optional and defaults to https://api.koverse.dev
# See configuration.py for a list of all supported configuration parameters.
configuration = kdp_api.Configuration(
    host = "https://api.koverse.dev"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (JWT): Bearer
configuration = kdp_api.Configuration(
    access_token = 'YOUR_BEARER_TOKEN'
)

# Enter a context with an instance of the API client
with kdp_api.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = read_api.ReadApi(api_client)
    sequence_read_request = SequenceReadRequest(
        dataset_id="dataset_id_example",
        batch_size=1,
        starting_record_id="starting_record_id_example",
        credentials_subset=[
            "credentials_subset_example",
        ],
    ) # SequenceReadRequest | 

    # example passing only required values which don't have defaults set
    try:
        # Read all records for dataset
        api_response = api_instance.read_in_sequence(sequence_read_request)
        pprint(api_response)
    except kdp_api.ApiException as e:
        print("Exception when calling ReadApi->read_in_sequence: %s\n" % e)
```


### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sequence_read_request** | [**SequenceReadRequest**](SequenceReadRequest.md)|  |

### Return type

[**RecordBatch**](RecordBatch.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*


### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

