import pandas as pd

from pprint import pprint

from timeit import default_timer as timer

from kdp_connector import KdpConn

# This example shows you how to use the KDP Python Connector to write data into KDP platform
# from Pandas dataframe sourced from a csv file.
# Also shows how to read the data back from the KDP platform into a dataframe.

# Only authentication details (username and password) are required for this example
########### variables ###########################################
# authentication code
email = '${email}'
password = '${password}'

# OPTIONAL: When not provided will not verify ssl of request. Which will result in warnings in the log.
# See configuration/configurationUtil.py for more detail about using certificates for ssl.
path_to_ca_file = ''

# host url to KDP platform (change to 'https://api.koverse.localhost' for running against local application instance)
# host = 'https://api.koverse.localhost'
host = 'https://api.koverse.dev'

#################################################################

# OTHER CONFIGURATIONS
workspace_id = 'Films'

# dataset id: OPTIONAL (Provide an existing dataset id, if you don't want to create a new dataset)
# EXAMPLE: dataset_id = 'e5a31d9f-1b6e-49c2-9db3-7c86b404be2f'
dataset_id = ''
dataset_name = 'Actors in Films'

# number of records in a batch
ingest_batch_size = 1000
read_batch_size = 100000

# csv file location
input_file = './resources/actorfilms.csv'

##################################################

# Read input into dataframe
df = pd.read_csv(input_file)

# Construct kdpConnector
kdp_conn = KdpConn(path_to_ca_file, host, discard_unknown_keys=True)

jwt = kdp_conn.create_authentication_token(email=email,
                                           password=password,
                                           workspace_id=workspace_id)

# Get workspace
workspace = kdp_conn.get_workspace(workspace_id, jwt)
pprint("Retrieved workspace by id: %s" % workspace.id)

# Get or Create Dataset
if dataset_id != '':
    dataset = kdp_conn.get_dataset(dataset_id, jwt)
    pprint("Retrieved dataset by id %s" % dataset.id)
else:
    dataset = kdp_conn.create_dataset(name=dataset_name, workspace_id=workspace.id, jwt=jwt)
    pprint("Created dataset with name: %s and dataset.id: %s" % (dataset_name, dataset.id))

# ingest data
partitions_set = kdp_conn.ingest(df, dataset.id, jwt, ingest_batch_size)

pprint('File ingest completed with partitions: %s' % partitions_set)

start = timer()

starting_record_id = ''

dataframe = kdp_conn.read_dataset_to_pandas_dataframe(dataset_id=dataset.id,
                                                      jwt=jwt,
                                                      starting_record_id=starting_record_id,
                                                      batch_size=read_batch_size)

end = timer()

print('Created pandas dataframe with', dataframe.size, 'elements (number of columns times number of rows) in ',
      end - start, 'seconds')

if dataframe.size < 10000:
    pprint(dataframe)
