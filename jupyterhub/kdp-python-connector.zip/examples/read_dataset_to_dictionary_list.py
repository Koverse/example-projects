from timeit import default_timer as timer

import pandas as pd

from kdp_connector import KdpConn

# This example shows you how to use the KDP Python Connector to read data from KDP dataset into
# a Pandas Dataframe.

# authentication code
email = '${email}'
password = '${password}'

# workspace id
workspace_id = '${WORKSPACE_ID}'

# dataset id
dataset_id = '${DATASET_ID}'

# OPTIONAL: host url to KDP platform, default: 'https://api.koverse.dev'
host = 'https://${KDP_API_HOST}'

# OPTIONAL: number of records to read per batch when writing to dataframe, default:1000;
batch_size = 100000

# OPTIONAL: When provided the dataset will be starting from the record following the starting_record_id
starting_record_id = ''

#####################################################
# OPTIONAL: When not provided will not verify ssl of request. Which will result in warnings in the log.
# See configuration/configurationUtil.py for more detail about using certificates for ssl.
path_to_ca_file = ''

#####################################################


start = timer()

kdp_conn = KdpConn(path_to_ca_file, host)

jwt = kdp_conn.create_authentication_token(email=email,
                                           password=password,
                                           workspace_id=workspace_id)

dictionary_list = kdp_conn.read_dataset_to_dictionary_list(dataset_id=dataset_id,
                                                           jwt=jwt,
                                                           starting_record_id=starting_record_id,
                                                           batch_size=batch_size)

end = timer()

print('Read', len(dictionary_list), 'records in', end - start, 'seconds')

start_pandas = timer()
dataframe = pd.DataFrame(dictionary_list)
end_pandas = timer()

if dataframe.size < 5000:
    print(dataframe)

print('Created pandas dataframe with', dataframe.size, 'elements (number of columns times number of rows) in ',
      end_pandas - start_pandas, 'seconds')
